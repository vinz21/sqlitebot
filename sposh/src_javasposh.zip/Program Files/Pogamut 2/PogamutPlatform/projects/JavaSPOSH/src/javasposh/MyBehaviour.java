package javasposh;

//import cz.cuni.pogamut.MessageObjects.Player;
//import cz.cuni.pogamut.MessageObjects.Triple;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

//import cz.cuni.pogamut.MessageObjects.AddWeapon;
//import cz.cuni.pogamut.MessageObjects.Health;
//import cz.cuni.pogamut.MessageObjects.Item;
//import cz.cuni.pogamut.MessageObjects.Weapon;
import cz.cuni.sposhBot.java.JavaBehaviour;
import cz.cuni.sposhBot.java.SPoshBot;

import java.util.logging.Logger;

//

import cz.cuni.pogamut.Client.Agent;
import cz.cuni.pogamut.Client.RcvMsgEvent;
import cz.cuni.pogamut.Client.RcvMsgListener;
import cz.cuni.pogamut.MessageObjects.*;
import cz.cuni.pogamut.introspection.PogProp;
import cz.cuni.pogamut.exceptions.ConnectException;
import cz.cuni.pogamut.exceptions.PogamutException;

import java.io.IOException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;




/**
 * Here is the place to implement your acts and senses
 * The log domain of a behaviour is set to class name.
 *
 * act:
 *     in plan file: shoot
 *     in behaviour: public void action_shoot()
 * sense:
 *     in plan file: hear
 *     in behaviour: public boolean sense_hear()
 *
 * E.g. see action_doNothing() /  sense_fail()
 */
public class MyBehaviour extends JavaBehaviour {
    
    protected Item choosenItem = null;
    protected Item previousChoosenItem = null;
    public ArrayList<Item> itemsToRunAround = new ArrayList<Item>();
    public ArrayList<Item> medkitsToRunAround = null;

    protected boolean jumped = true;
    protected boolean medsRestart = true;

    @PogProp NavPoint chosenNavigationPoint = null;
    @PogProp NavPoint lastNavigationPoint = null;

    Player enemy = null;
    double gameTime = 0.0;
    double turnTime = 0.0;

    boolean strafingRight = true;

    public MyBehaviour(String name, Logger log, SPoshBot bot) {
        super(name, log, bot);
    }

/************************************************************************
* actions *
*************************************************************************/

    public boolean action_rearm() {
	this.log.info("Action REARM.");
    	AddWeapon weapon = this.bot.getMemory().getBetterWeapon(this.bot.getMemory().getSeeEnemy().location, this.bot.getMemory().getAgentLocation());
    	this.bot.getBody().changeWeapon(weapon);
    	return true;
    }
    
    public boolean action_engageEnemy() {
	this.log.info("Action ENGAGE_ENEMY.");
    	//this.medsRestart = true;
    	this.bot.getBody().shoot(this.bot.getMemory().getSeeEnemy());
    	return true;
    }
    
    public boolean action_runAroundCloseMeds() {
	this.log.info("Action RUN_AROUND_CLOSE_MEDS.");    	
    	this.bot.getMap().runAroundItemsInTheMap(this.medkitsToRunAround, false);    	
    	return true;
    }
    
    public boolean action_runAroundItems() {
	this.log.info("Action RUN_AROUND_ITEMS.");
    	this.bot.getMap().runAroundItemsInTheMap(this.itemsToRunAround, false);
    	return true;
    }
    
    public boolean action_runToItem() {
	this.log.info("Action RUN_TO_ITEM.");
        if(!this.bot.getMap().safeRunToLocation(choosenItem.location)) {
            // unable to reach the choosen item
            log.info("unable to REACH the choosen item");
            previousChoosenItem = choosenItem;
            choosenItem = null;
        }
        return true;
    }
    
    public boolean action_stopShooting() {
		this.log.info("Action STOP_SHOOTING.");
		this.bot.getBody().stopShoot();
		return true;
    }
    
    public boolean action_jump() {
        this.log.info("Action JUMP.");
        if (this.bot.getMemory().isColliding())
                if (!this.jumped){
                        this.bot.getBody().jump();
                        this.jumped = true;
                } else {
                        this.bot.getBody().stop();
                        this.jumped = false;
                }
        if (this.bot.getMemory().isFalling()){
                this.bot.getBody().sendGlobalMessage("I am flying like a bird:D!");
                this.log.info("I'm flying like an angel to the sky ... it's so high ... oh, I am high! :-)");
        }
        if (this.bot.getMemory().isBumpingToAnotherActor()){
                this.bot.getBody().stop();
        }
        return true;
    }
    
    public boolean action_doNothing() {        
    	return true;
    }

    public boolean action_sleep200ms() {         
        Random r = new Random();
        int myRandSleep = r.nextInt(100);
        try {
            Thread.sleep(200+myRandSleep);
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
    }

    public boolean action_navigateBot() {
        //log.info("navigateBot");
        // if don't have any navigation point chosen
        if (chosenNavigationPoint == null) {
            this.log.info("Action NAVIGATE-RANDOM.");
            // let's pick one at random
            //try { setNavpoint(behavior); } catch (Exception K) { System.out.println("Hello World!"); }
            Random r = new Random();
            chosenNavigationPoint = bot.getMemory().getKnownNavPoints().get(r.nextInt(bot.getMemory().getKnownNavPoints().size()));
            log.fine("navpoint_logic="+chosenNavigationPoint.UnrealID);
            log.fine("map_id_logic="+chosenNavigationPoint.getID());
       }
        // here we're sure the chosenNavigationPoint is not null
        // call method iteratively to get to the navigation point

        //if (chosenNavigationPoint == lastNavigationPoint) { return; }
        //if (Triple.distanceInSpace(memory.getAgentLocation(), chosenNavigationPoint.location) < 100) { return; }
//log.info("debugMain2"+chosenNavigationPoint.location.toString());
        /*
        if (weaponGet != null) {log.info("debugMain2:"+weaponGet.weaponType.toString()); }
        if (healthGet != null) {log.info("debugMain2:"+healthGet.UnrealID.toString()); }
        if (weaponGetPickup != null) {log.info("debugMain2WPickup:"+weaponGetPickup.weaponType.toString()); }
        if ((runType != null) && runType.equals("runto")) {
          log.info("runtopickup");


          if (Triple.distanceInSpace(memory.getAgentLocation(), chosenNavigationPoint.location) < 100) {
               //(!chosenNavigationPoint.isVisible())) {
              runType = null;
              weaponGetPickup = null;
              return;
          }
          body.runToLocation(chosenNavigationPoint.location);
        return;
        }
        */
        if (!bot.getMap().safeRunToLocation(chosenNavigationPoint.location)) {
            log.info("debugMain4"+chosenNavigationPoint.location.toString());

        //if (!gameMap.safeRunToLocationNav(chosenNavigationPoint)) {
            // if safeRunToLocation() returns false it means
            //log.info("chosen_dist:"+Triple.distanceInSpace(memory.getAgentLocation(), chosenNavigationPoint.location));
            if (Triple.distanceInSpace(bot.getMemory().getAgentLocation(), chosenNavigationPoint.location) < 100) {
                // 1) we're at the navpoint
                log.info("I've successfully arrived at navigation point!");
                //bot.getMap()..resetPath();
                //weaponGet = null;
                //healthGet = null;

                //Triple campFocusLocation = new Triple (-1520.0,1450.0,-207.0);
                //this.body.turnToLocation(campFocusLocation);
            } else {
                // 2) something bad happens
                log.info("Darn the path is broken :(:"+Triple.distanceInSpace(bot.getMemory().getAgentLocation(), chosenNavigationPoint.location));
                //this.body.runToLocation(lastNavigationPoint.location);
                if (bot.getMemory().getSeeAnyNavPoint()) {
                  bot.getBody().runToLocation(bot.getMemory().getSeeNavPoint().location);
                }
                else {
                  bot.getBody().turnHorizontal(180);
                }
                //if we're stuck trying to get a weapon, forget about for a while(default timer length=40 sec)
                /*if (weaponGet != null) {
                  timerMap.put(Integer.toString(weaponGet.ID), new Double (Double.toString(gameTime)));
                  weaponGet = null;
                }
                if (healthGet != null) {
                  timerMap.put(Integer.toString(healthGet.ID), new Double (Double.toString(gameTime)));
                  healthGet = null;
                }
                */

                //Triple campFocusLocation = new Triple (-1520.0,1450.0,-207.0);
                //this.body.turnToLocation(campFocusLocation);
            }
            // nullify chosen navigation point and chose it during the
            // next iteration of the logic
            lastNavigationPoint = chosenNavigationPoint;
            chosenNavigationPoint = null;
        }

   return true;
}

/************************************************************************
* senses *
*************************************************************************/

    public boolean sense_fail() {
        return false;
    }
    
    public boolean sense_succeed() {
        return true;
    }
    
    public boolean sense_stucked() {
    	return bot.getMemory().isColliding();
    }
    
    public boolean sense_isShooting() {
    	return bot.getMemory().isShooting();
    }
    
    public boolean sense_hasBetterWeapon() {
        Triple botLoc = bot.getMemory().getAgentLocation();
        Player enemy = bot.getMemory().getSeeEnemy();
        if (enemy == null || enemy.location == null)
            return false;
    	AddWeapon candidate = bot.getMemory().getBetterWeapon(botLoc, enemy.location);
    	if (candidate != null)
    		return true;
    	else
    		return false;
    }
    
    public int sense_health() {    	
    	return bot.getMemory().getAgentHealth();
    }
    
    public boolean sense_knowMedkits() {
    	if (medsRestart)
    		this.medkitsToRunAround = null;
    	if (this.medkitsToRunAround != null)
    		return true;
    	ArrayList<Item> healths = this.bot.getMap().nearestHealth(15, 4);
    	if (healths == null || healths.size() < 2)
    		return false;
		this.medkitsToRunAround = healths;
		return true;
    }
    
    public boolean sense_armed() {
    	return bot.getMemory().hasAnyLoadedWeapon();
    }
    
    public boolean sense_seeEnemy() {
    	return bot.getMemory().getSeeAnyEnemy();
    }
    
    public boolean sense_seeItemAndWantIt() {
    	return this.seeAnyReachableItemAndWantIt();
    }

//    @Override
//    @SuppressWarnings("static-access")
//    public void receiveMessage(RcvMsgEvent e) {
    public String sense_gbMessage() {
    // DO NOT DELETE! Otherwise things will screw up! Agent class itself is also using this listener...
        //super.receiveMessage(RcvMsgEvent e);
        //RcvMsgEvent e = null;
        /* super.bot.receiveMessage(RcvMsgEvent e);
        log.info("gbMessage:"+e.getMessage().type.toString());
        return e.getMessage().type.toString(); */
//return e.getMessage().ID;
        return "WALL_COLLISIaON";
        /*
        if (e.getMessage().type.toString().equals("NAV_POINT")) { return; }
        if (e.getMessage().type.toString().equals("DELETE_FROM_BATCH")) { return; }
        if (e.getMessage().type.toString().equals("WEAPON")) { return; }
        if (e.getMessage().type.toString().equals("CHANGE_WEAPON")) { return; }
        if (e.getMessage().type.toString().equals("CHANGED_WEAPON")) { return; }
        if (e.getMessage().type.toString().equals("ITEM")) { return; }
        if (e.getMessage().type.toString().equals("AMMO")) { return; }
        if (e.getMessage().type.toString().equals("MOVER")) { return; }
        //if (e.getMessage().type.toString().equals("BEGIN")) { return; }
        if (e.getMessage().type.toString().equals("END")) { return; }
        if (e.getMessage().type.toString().equals("GAME_STATUS")) { return; }
        if (e.getMessage().type.toString().equals("SELF")) { return; }
        if (e.getMessage().type.toString().equals("HEALTH")) { return; }
        if (e.getMessage().type.toString().equals("ADD_ITEM")) { return; }
        if (e.getMessage().type.toString().equals("ADD_AMMO")) { return; }
        if (e.getMessage().type.toString().equals("ADD_HEALTH")) { return; }
        if (e.getMessage().type.toString().equals("ADD_SPECIAL")) { return; }
        if (e.getMessage().type.toString().equals("ADD_WEAPON")) { return; }
        if (e.getMessage().type.toString().equals("ADRENALINE_GAINED")) { return; }
        if (e.getMessage().type.toString().equals("ARMOR")) { return; }
        if (e.getMessage().type.toString().equals("SPECIAL")) { return; }
        if (e.getMessage().type.toString().equals("HEAR_NOISE")) { return; }
        if (e.getMessage().type.toString().equals("HEAR_PICKUP")) { return; }
        if (e.getMessage().type.toString().equals("PLAYER")) { return; }
        if (e.getMessage().type.toString().equals("PATH")) { return; }
*/
/*        if (!(e.getMessage().type.toString().equals("BEGIN"))) {
          //  getLogger().info("message: " + e.getMessage().type.toString());
                      log.info("message: " + e.getMessage().type.toString());
        }
        // Take care of frags and deaths.
        switch (e.getMessage().type) {
/*            case PLAYER_KILLED:
              PlayerKilled pk;

              pk = (PlayerKilled) e.getMessage();
              if (pk.killerID == getMemory().getAgentID()) {
                frags += 1;
                //getLogger().info("pk: "+pk.killerID+":"+lastEnemy.ID+":"+pk.ID+":"+this.memory.getAgentID());
                try { dbWrite(memory.getGameInfo().level.toString(),chosenNavigationPoint.getID(),memory.getKnownNavPoints().indexOf(chosenNavigationPoint),chosenNavigationPoint.location.toString(),chosenNavigationPoint.UnrealID.toString(),memory.getAgentLocation().toString(),gameTime, 1); } catch (Exception K) { System.out.println("Hello World!"); }
              }

              //frags += 1;

              //to correct bot pursuing after dead enemy disappears
              if (pk.killerID == this.memory.getAgentID()) {
                //log.info("got'EM");
                lastEnemy = null;
              }

              break;
            case BOT_KILLED:
              BotKilled bk;

              bk = (BotKilled) e.getMessage();
              //if (bk.killerID == getMemory().getAgentID()) {
                deaths += 1;
                getLogger().info("bk: " + bk.killerID);
                //getLogger().info("location:"+memory.getAgentLocation().toString());
                //probably should avoid places killed, but trying returning to the scene of the crime for now
                try { dbWrite(memory.getGameInfo().level.toString(),chosenNavigationPoint.getID(),memory.getKnownNavPoints().indexOf(chosenNavigationPoint),chosenNavigationPoint.location.toString(),chosenNavigationPoint.UnrealID.toString(),memory.getAgentLocation().toString(),gameTime, 1); } catch (Exception K) { System.out.println("Hello World!"); }
              //}

               //System.exit(0);

              //deaths += 1;
              break;
 */
 /*           case GLOBAL_CHAT:
              GlobalChat gc;

              gc = (GlobalChat) e.getMessage();
              log.info("Message: " + gc.string);
              break;
            case BEGIN:
              BeginMessage begin;

              begin = (BeginMessage) e.getMessage();
              //getLogger().info("Message: " + begin.time);
              gameTime = begin.time;
              break;
            case WALL_COLLISION:
              strafingRight = !strafingRight;
              Random r = new Random();
              int myWCRand = r.nextInt(3)+1;
              if (myWCRand == 1) { this.bot.getBody().jump(); }
              if (myWCRand == 2) { this.bot.getBody().doubleJump(); }
              break;
  */
/*            case INCOMMING_PROJECTILE:

                int myRand = random.nextInt(5)+1;

            int myRandSleep = random.nextInt(100);
            try {
                Thread.currentThread().sleep(200+myRandSleep);
            } catch (InterruptedException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }

                if (myRand == 1) {
                  log.info("dodge right");
                  Triple dodgeDirection = new Triple (0.0,1.0,0.0);
                  this.body.dodge(dodgeDirection);
                }
                if (myRand == 2) {
                  log.info("dodge left");
                  Triple dodgeDirection = new Triple (0.0,-1.0,0.0);
                  this.body.dodge(dodgeDirection);
                }
                if (myRand == 3) {
                  log.info("jump");
                  this.body.jump();
                }

/*
        if (turnTime == 0.0) {
            turnTime = gameTime;
        }
        double waitTimeHit = 0.0;
        double maxEffectTime = 5.0;
        //only perform turn if within last waitTimeHit seconds

        log.info(gameTime+":"+turnTime);
        if ((gameTime >= turnTime+waitTimeHit) && (gameTime <= turnTime+maxEffectTime)) {
            log.info("INCOMMING register");
            //this.body.turnHorizontal(180);
                int myRand = random.nextInt(3)+1;

                if (myRand == 1) {
                  log.info("dodge right");
                  Triple dodgeDirection = new Triple (0.0,1.0,0.0);
                  this.body.dodge(dodgeDirection);
                }
                if (myRand == 2) {
                  log.info("dodge left");
                  Triple dodgeDirection = new Triple (0.0,-1.0,0.0);
                  this.body.dodge(dodgeDirection);
                }
                if (myRand == 3) {
                  log.info("jump");
                  this.body.jump();
                }
        }
        else {
            log.info("INCOMMING ignored");
            if (gameTime > turnTime+maxEffectTime) {
              log.info("turntime reset");
              turnTime = 0.0;
            }
        }
* /

              break;
            case SPAWN:
              runType = null;
              weaponGetPickup = null;
              weaponGet = null;
              break;
              * /
        }
    */
    }



    //#############################################################
    // auxiliary functions
    //#############################################################

    
    /** 
     * choose weapon according to the one he is currently holding
     * <ol>
     * <li> has melee and see ranged => pick up ranged
     * <li> has ranged and see melee => pick up melee
     * <li> pick up first weapon he sees
     * </ol>
     * 
     * @return the choosen one weapon
     */
    private Weapon chooseWeapon() {
            ArrayList<Weapon> weapons = bot.getMemory().getSeeReachableWeapons();			
            for (Weapon weapon:weapons) {
                    // 0) has no weapon in hands
                    if (this.bot.getMemory().getCurrentWeapon() == null)
                            return weapon;
                    // 1) weapon is ranged, bot has melee
                    if ((this.bot.getMemory().getCurrentWeapon().melee) && !weapon.isMelee() && !this.bot.getMemory().hasWeaponOfType(weapon.weaponType)){
                            return weapon;
                    }
                    // 2) weapon is melee, bot has ranged
                    if (!this.bot.getMemory().getCurrentWeapon().melee && weapon.isMelee() && !this.bot.getMemory().hasWeaponOfType(weapon.weaponType)){
                            return weapon;
                    }
            }
            Weapon chosen = this.bot.getMemory().getSeeReachableWeapon();
            if (!this.bot.getMemory().hasWeaponOfType(chosen.weaponType)){
                    return chosen;
            }
            return null;
    }
	
    /**
     * Reasoning about what to do with seen item <br>
     * the easiest way of handeling it will be just to take it every time, but what should we do
     * when there are many of items laying in front of agent?
     * <ol>
     * <li> choose weapon - choose the type he is lacking (melee/ranged)
     * <li> choose armor
     * <li> choose health - if the health is bellow normal maximum
     * <li> choose ammo - if it is suitable for possessed weapons
     * <li> ignore the item
     * </ol>
     */
    private Item chooseItem() {
            // 1) choose weapon - choose the type he is lacking (melee/ranged)
            if (this.bot.getMemory().getSeeAnyReachableWeapon())
                    return chooseWeapon();
            // 2) choose armor
            if (this.bot.getMemory().getSeeAnyReachableArmor())
                    return this.bot.getMemory().getSeeReachableArmor();
            // 3) choose health - if the health is bellow normal maximum or the item is boostable
            if (this.bot.getMemory().getSeeAnyReachableHealth()) {
                    Health health = this.bot.getMemory().getSeeReachableHealth();
                    if (this.bot.getMemory().getAgentHealth() < 100)
                            return health;
                    if (health.boostable) // if the health item is boostable, grab it anyway:)
                            return health;
            }	
            // 4) choose ammo - if it is suitable for possessed weapons
            if ((this.bot.getMemory().getSeeAnyReachableAmmo()) && 
                    (this.bot.getMemory().isAmmoSuitable(this.bot.getMemory().getSeeReachableAmmo())))
                    return this.bot.getMemory().getSeeReachableAmmo();
            // 5) ignore the item
            return null;
    }

    /** 
     * sees reachable item and wants it
     * @return true if there is an item which is useful for agent
     */
    private boolean seeAnyReachableItemAndWantIt() {
            if (this.bot.getMemory().getSeeAnyReachableItem()){
                    choosenItem = chooseItem();
                    if (choosenItem != null) {
                            this.log.info("NEW ITEM CHOSEN: " + choosenItem);
                            this.log.info("LAST CHOOSEN ITEM: " + previousChoosenItem);
                    }
            } else {
                    choosenItem = null;
            }
            if ((choosenItem != null) && (!choosenItem.equals(previousChoosenItem)))
                //&& (Triple.distanceInSpace(memory.getAgentLocation(), choosenItem.location) > 20))
                return true;
            else
                return false;
    }

}